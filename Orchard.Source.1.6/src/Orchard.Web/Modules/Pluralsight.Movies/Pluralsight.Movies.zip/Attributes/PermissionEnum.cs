namespace Pluralsight.Movies.Attributes {
    public enum PermissionEnum {
        LookupMovie
    }
}