namespace Pluralsight.Movies.Models {
    public enum MPAARating {
        G,
        PG,
        PG13,
        R
    }
}